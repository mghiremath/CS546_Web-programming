import { bandDataFunctions } from "./bands.js";
import { albumDataFunctions } from "./albums.js";

export const bandData = bandDataFunctions;
export const albumData = albumDataFunctions;
