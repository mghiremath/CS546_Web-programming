export const mongoConfig = {
  serverUrl: "mongodb://localhost:27017/",
  database: "Maheshwarswami_Hiremath_lab4",
};
